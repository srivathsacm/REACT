import React,{useState,useMemo} from "react";

function WithUseMemo(){
    const[count,setCount]=useState(0);
    const[text,setText]=useState("");

    function slowCalculation(num){
        console.log("Running slow calculation.....");
        for(let i=0;i<10000000000;i++){}
        return num*2;
    }
    const result=useMemo(()=>slowCalculation(count),[count]);
    console.log(result);
    

    return(
        <div>
            <h3>Slow Result:{result}</h3>
            <button onClick={()=>setCount(count+1)}>Increment</button>
            <input value={text} onChange={(e)=>setText(e.target.value)} placeholder="Type here...." />
        </div>
    );
}
export default WithUseMemo