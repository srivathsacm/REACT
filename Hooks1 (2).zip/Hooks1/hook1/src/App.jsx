import React from 'react'
import Component1 from './ContextAPI'
import Ref from './UseRef'
import AccesDom from './AccesDom'
import Track from './Track.jsx'
import Counter from './UseReducer.jsx'
import WithUseMemo from './UseMemo.jsx'
import Parent from './UseCallback.jsx'
import CounterApp from './CounterApp.jsx'



function App() {
  return (
    <div>
      <Component1/>
      <Ref/>
      <AccesDom/>
      <Track/>
      <Counter/>
      <WithUseMemo/>
      <Parent/>
     <CounterApp/>
    </div>
  )
}

export default App
