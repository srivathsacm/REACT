import About from "./About";
import SmartTodo from "./Todo";

function App() {
   return (
    <div>
        <SmartTodo />
        <About/>
        </div>
      
  );
}


export default App;
