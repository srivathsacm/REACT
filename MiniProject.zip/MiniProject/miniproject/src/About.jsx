import React from "react";

export default function About() {
  return (
    <div style={styles.container}>
      <div style={styles.card}>
        <h1 style={styles.title}>About Smart To-Do Manager</h1>
        <p style={styles.text}>
          <strong>Smart To-Do Manager</strong> is a simple and efficient React
          application designed to help you manage your daily tasks easily.
          You can add, edit, delete, and mark tasks as complete or pending.
        </p>

        <p style={styles.text}>
          This project demonstrates core React concepts such as:
        </p>

        <ul style={styles.list}>
          <li>Component-based architecture</li>
          <li>State management using useState and useEffect</li>
          <li>Routing with React Router</li>
          <li>Controlled forms and input validation</li>
          <li>Local storage data persistence</li>
        </ul>

        <p style={{ ...styles.text, fontStyle: "italic" }}>
          “Stay organized, stay productive!”
        </p>

        <footer style={styles.footer}>
          <p>Developed by <strong>SRIVATHSA</strong></p>
          <p>© {new Date().getFullYear()} All rights reserved.</p>
        </footer>
      </div>
    </div>
  );
}

const styles = {
  container: {
    minHeight: "100vh",
    display: "flex",
    justifyContent: "center",
    alignItems: "center",
    backgroundColor: "#f5f5f5",
    padding: "20px",
  },
  card: {
    backgroundColor: "white",
    borderRadius: "10px",
    padding: "30px",
    maxWidth: "600px",
    boxShadow: "0 4px 10px rgba(0,0,0,0.1)",
    textAlign: "center",
  },
  title: {
    fontSize: "2rem",
    marginBottom: "15px",
    color: "#333",
  },
  text: {
    fontSize: "1rem",
    color: "#555",
    marginBottom: "10px",
    lineHeight: "1.6",
  },
  list: {
    textAlign: "left",
    color: "#444",
    marginBottom: "20px",
    paddingLeft: "20px",
  },
  footer: {
    marginTop: "30px",
    fontSize: "0.9rem",
    color: "#777",
  },
};
